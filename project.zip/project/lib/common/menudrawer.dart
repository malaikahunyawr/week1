import 'package:flutter/material.dart';
import 'package:sem_project/screens/aboutus.dart';
import 'package:sem_project/screens/bookingInfo.dart';
import 'package:sem_project/screens/contactus.dart';
import 'package:sem_project/screens/sliders.dart';
import 'package:sem_project/screens/terms.dart';

class MenuDrawer extends StatelessWidget {
  const MenuDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(children: buildMenuItems(context)),
      backgroundColor: Colors.blue,
    );
  }

  List<Widget> buildMenuItems(BuildContext context) {
    List<Widget> menuItems = [];

    menuItems.add(const DrawerHeader(
        child: Center(
      child: Text(
        "Book me",
        style: TextStyle(
            fontSize: 30,
            color: Colors.white,
            fontStyle: FontStyle.italic,
            fontWeight: FontWeight.bold),
      ),
    )));

    final Set<String> menuTitles = {
      "Home",
      "Booking Details",
      "About Us",
      "Contact Us",
      "Terms and Conditions"
    };

    menuTitles.forEach((element) {
      menuItems.add(ListTile(
        title:
            Text(element, style: TextStyle(fontSize: 20, color: Colors.white)),
        onTap: () {
          Widget screen = Container();

          switch (element) {
            case 'Home':
              screen = const Sliders();
              break;
            case 'Booking Details':
              screen = BookingInfo();
              break;
            case 'About Us':
              screen = const AboutUs();
              break;
            case 'Contact Us':
              screen = const ContactUs();
              break;
            case 'Terms and Conditions':
              screen = Terms();
              break;

            default:
          }

          Navigator.of(context).pop();
          Navigator.of(context)
              .push(MaterialPageRoute(builder: (context) => screen));
        },
      ));
    });
    return menuItems;
  }
}
