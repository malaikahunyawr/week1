import 'dart:convert';

import 'package:flutter/material.dart';

class booking_entry {
  int id = 0;
  String name = "";
  String email = "";
  String CNIC = "";
  String phone_no = "";
  String seat_no = "";
  String seat_type = "";
  String route = "";
  DateTime departure_date = DateTime.now();
  TimeOfDay departure_time = TimeOfDay(hour: 9, minute: 0);

  booking_entry(this.name, this.email, this.CNIC, this.phone_no, this.seat_no,
      this.seat_type, this.route, this.departure_date, this.departure_time);

  String toJson() {
    return json.encode({
      "id": id,
      "name": name,
      "email": email,
      "CNIC": CNIC,
      "phone_no": phone_no,
      "seat_no": seat_no,
      "seat_type": seat_type,
      "route": route,
      "departure_date": departure_date,
      "departure_time": departure_time
    });
  }

  booking_entry.fromJson(String dataString) {
    var data = json.decode(dataString);
    id = data["id"] ?? 0;
    name = data["name"] ?? "";
    email = data["email"] ?? "";
    CNIC = data["CNIC"] ?? "";
    email = data["email"] ?? "";
    phone_no = data["phone_no"] ?? "";
    seat_no = data["seat_no"] ?? "";
    seat_type = data["seat_type"] ?? "";
    route = data["route"] ?? "";
    departure_date = data["departure_date"] ?? "";
    departure_time = data["departure_time"] ?? "";
  }
}
