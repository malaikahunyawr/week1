import 'package:shared_preferences/shared_preferences.dart';
import 'package:sem_project/data/booking_entry.dart';

class Sharedpref {
  late SharedPreferences spref;

  Future init() async {
    spref = await SharedPreferences.getInstance();
  }

  int getExisitingCounter() {
    return spref.getInt("counter") ?? 1;
  }

  Future writeBookingEntry(booking_entry entry) async {
    await spref.setString(entry.id.toString(), entry.toJson());
    int exitingCounter = spref.getInt("counter") ?? 1;
    await spref.setInt("counter", exitingCounter + 1);
  }

  booking_entry readSportsEntry(int id) {
    return booking_entry.fromJson(spref.getString(id.toString()) ?? "");
  }

  List<booking_entry> getAllofBookingData() {
    List<booking_entry> listBookingEnties = [];

    var keys = spref.getKeys();

    keys.forEach((key) {
      if (key != "counter") {
        var jsonString = spref.getString(key);
        booking_entry entry = booking_entry.fromJson(jsonString ?? "");
        listBookingEnties.add(entry);
      }
    });

    return listBookingEnties;
  }
}
