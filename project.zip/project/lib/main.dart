import 'package:flutter/material.dart';
import 'package:sem_project/screens/aboutus.dart';
import 'package:sem_project/screens/bookingInfo.dart';
import 'package:sem_project/screens/contactus.dart';
import 'package:sem_project/screens/getstarted.dart';
import 'package:sem_project/screens/sliders.dart';
import 'package:sem_project/screens/bookingpage.dart';
import 'package:sem_project/screens/terms.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      routes: {
        "/": (context) => GetStarted(),
        "/sliders": (context) => Sliders(),
        "/booking": (context) => BookingPage(),
        "/about": (context) => AboutUs(),
        "/contact": (context) => ContactUs(),
        "/terms": (context) => Terms(),
        "/Info": (context) => BookingInfo()
      },
    );
  }
}
