import 'package:flutter/material.dart';
import 'package:sem_project/common/menudrawer.dart';
import 'package:sem_project/screens/busdetail.dart';

class BookingInfo extends StatelessWidget {
  const BookingInfo({Key? key}) : super(key: key);

  void _showBusDetails(BuildContext context, String busType, String details) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) =>
            BusDetailsScreen(busType: busType, details: details),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Booking Info'),
        backgroundColor: Colors.blueAccent,
        foregroundColor: Colors.white,
      ),
      drawer: const MenuDrawer(),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            GestureDetector(
              onTap: () => _showBusDetails(
                context,
                'Business Class',
                '''
                **Overview**: The Business Class buses are designed to offer an elevated travel experience with superior comfort and premium amenities.

                **Seating Capacity**: 40 seats

                **Features**:
                - **Comfortable Seating**: Plush, adjustable seats with extra legroom for a more relaxing journey.
                - **Wi-Fi**: Complimentary high-speed Wi-Fi to keep you connected throughout the journey.
                - **Refreshments**: Complimentary snacks and beverages served onboard.
                - **Entertainment**: Personal entertainment systems with a wide selection of movies, music, and games.
                - **Climate Control**: Advanced air conditioning and heating systems to ensure a comfortable environment.
                - **Cleanliness**: Regular cleaning and sanitization for a hygienic travel experience.
                - **Power Outlets**: Individual power outlets and USB ports for charging devices.
                ''',
              ),
              child: Stack(
                children: [
                  AspectRatio(
                    aspectRatio: 4 / 3,
                    child: Image.asset(
                      'assets/buisness.jpeg',
                      fit: BoxFit.cover,
                    ),
                  ),
                  Positioned.fill(
                    child: Center(
                      child: Text(
                        'Business Class',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          shadows: [
                            Shadow(
                              color: Colors.black,
                              offset: Offset(2, 2),
                              blurRadius: 4,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            GestureDetector(
              onTap: () => _showBusDetails(
                context,
                'Economy Class',
                '''
                **Overview**: The Economy Class buses provide a comfortable and affordable travel option with essential amenities for a pleasant journey.

                **Seating Capacity**: 30 seats

                **Features**:
                - **Comfortable Seating**: Standard adjustable seats with adequate legroom.
                - **Wi-Fi**: Complimentary basic Wi-Fi service.
                - **Affordable Pricing**: Cost-effective travel option without compromising on basic comforts.
                - **Refreshments**: Optional purchase of snacks and beverages onboard.
                - **Entertainment**: Centralized entertainment system with a selection of movies and music.
                - **Climate Control**: Standard air conditioning and heating systems.
                - **Cleanliness**: Regular cleaning to maintain a clean environment.
                - **Power Outlets**: Shared power outlets and USB ports for charging devices.
                ''',
              ),
              child: Stack(
                children: [
                  AspectRatio(
                    aspectRatio: 4 / 3,
                    child: Image.asset(
                      'assets/Economy.jpeg',
                      fit: BoxFit.cover,
                    ),
                  ),
                  Positioned.fill(
                    child: Center(
                      child: Text(
                        'Economy Class',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          shadows: [
                            Shadow(
                              color: Colors.black,
                              offset: Offset(2, 2),
                              blurRadius: 4,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
