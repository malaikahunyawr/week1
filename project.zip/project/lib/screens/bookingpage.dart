import 'package:flutter/material.dart';
import 'package:sem_project/common/menudrawer.dart';
import 'package:sem_project/data/booking_entry.dart';
import 'package:sem_project/data/sharedpref.dart';

class BookingPage extends StatefulWidget {
  @override
  _BookingPageState createState() => _BookingPageState();
}

class _BookingPageState extends State<BookingPage> {
  Sharedpref sharedpref = Sharedpref();
  String _selectedSeatType = 'Business Class';
  String _selectedRoute = 'Lahore to Islamabad';
  String _name = '';
  String _email = '';
  String _cnic = '';
  String _phoneNo = '';
  String _seatNo = "1";
  DateTime _departureDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay(hour: 9, minute: 0);
  List<booking_entry> bookingEntries = [];

  bool _nameError = false;
  bool _emailError = false;
  bool _cnicError = false;
  bool _phoneNoError = false;
  bool _seatNoError = false;

  Map<String, int> bookedSeats = {
    'Lahore to Islamabad': 0,
    'Lahore to Faisalabad': 0,
    'Lahore to Multan': 0,
    'Multan to Lahore': 0,
    'Faisalabad to Lahore': 0,
    'Islamabad to Lahore': 0,
  };

  @override
  void initState() {
    super.initState();
    sharedpref.init().then((value) {
      setState(() {
        bookingEntries = sharedpref.getAllofBookingData();
        _initializeBookedSeats();
      });
    });
  }

  void _initializeBookedSeats() {
    for (var entry in bookingEntries) {
      if (bookedSeats.containsKey(entry.route)) {
        bookedSeats[entry.route] = bookedSeats[entry.route]! + 1;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Center(
          child: Text(
            'Booking Form',
            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
          ),
        ),
      ),
      drawer: const MenuDrawer(),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('image/abc.jpeg'),
            fit: BoxFit.cover,
          ),
        ),
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Booking form fields
                _buildBookingForm(),
                SizedBox(height: 20),
                _buildBookingEntriesList(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBookingForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ListTile(
          title: Text(
            'Name:',
            style: TextStyle(fontSize: 18),
          ),
          subtitle: TextField(
            onChanged: (value) {
              _name = value;
            },
            decoration: InputDecoration(
              hintText: 'Enter your name',
              errorText: _nameError ? 'This is a required field' : null,
            ),
            style: TextStyle(color: Colors.black),
          ),
        ),
        ListTile(
          title: Text(
            'Email:',
            style: TextStyle(fontSize: 18),
          ),
          subtitle: TextField(
            onChanged: (value) {
              _email = value;
            },
            decoration: InputDecoration(
              hintText: 'Enter your email',
              errorText: _emailError ? 'This is a required field' : null,
            ),
            style: TextStyle(color: Colors.black),
          ),
        ),
        ListTile(
          title: Text(
            'CNIC:',
            style: TextStyle(fontSize: 18),
          ),
          subtitle: TextField(
            onChanged: (value) {
              _cnic = value;
            },
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              hintText: 'Enter your CNIC',
              errorText: _cnicError ? 'This is a required field' : null,
            ),
            style: TextStyle(color: Colors.black),
          ),
        ),
        ListTile(
          title: Text(
            'Phone No.:',
            style: TextStyle(fontSize: 18),
          ),
          subtitle: TextField(
            onChanged: (value) {
              _phoneNo = value;
            },
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              hintText: 'Enter your phone number',
              errorText: _phoneNoError ? 'This is a required field' : null,
            ),
            style: TextStyle(color: Colors.black),
          ),
        ),
        ListTile(
          title: Text(
            'Seat No.:',
            style: TextStyle(fontSize: 18),
          ),
          subtitle: Text(
            _seatNo,
            style: TextStyle(color: Colors.black),
          ),
        ),
        Text(
          'Booking Details',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.blue,
          ),
        ),
        SizedBox(height: 20),
        ListTile(
          title: Text(
            'Seat Type:',
            style: TextStyle(fontSize: 18),
          ),
          subtitle: DropdownButton<String>(
            value: _selectedSeatType,
            onChanged: (String? newValue) {
              setState(() {
                _selectedSeatType = newValue!;
              });
            },
            items: <String>['Business Class', 'Economy Class']
                .map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
          ),
        ),
        ListTile(
          title: Text(
            'Route:',
            style: TextStyle(fontSize: 18),
          ),
          subtitle: DropdownButton<String>(
            value: _selectedRoute,
            onChanged: (String? newValue) {
              setState(() {
                _selectedRoute = newValue!;
                _seatNo = (bookedSeats[_selectedRoute]! + 1).toString();
              });
            },
            items:
                bookedSeats.keys.map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
          ),
        ),
        ListTile(
          title: Text(
            'Departure Date:',
            style: TextStyle(fontSize: 18),
          ),
          subtitle: InkWell(
            onTap: _pickDepartureDate,
            child: Text(
              _departureDate.toString().split(' ')[0],
              style: TextStyle(fontSize: 16, color: Colors.black),
            ),
          ),
        ),
        ListTile(
          title: Text(
            'Departure Time:',
            style: TextStyle(fontSize: 18),
          ),
          subtitle: DropdownButton<TimeOfDay>(
            value: _selectedTime,
            onChanged: (TimeOfDay? newValue) {
              setState(() {
                _selectedTime = newValue!;
              });
            },
            items: [
              TimeOfDay(hour: 9, minute: 0),
              TimeOfDay(hour: 17, minute: 0),
              TimeOfDay(hour: 22, minute: 0),
            ].map<DropdownMenuItem<TimeOfDay>>((TimeOfDay time) {
              return DropdownMenuItem<TimeOfDay>(
                value: time,
                child: Text('${time.format(context)}'),
              );
            }).toList(),
          ),
        ),
        SizedBox(height: 20),
        Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: ElevatedButton(
              onPressed: () async {
                await _validateFields();
              },
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.white,
                backgroundColor: Colors.blue,
                padding: EdgeInsets.symmetric(
                  vertical: 24.0,
                  horizontal: 40.0,
                ),
              ),
              child: Text(
                'Book Now',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildBookingEntriesList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Saved Booking Entries',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.blue,
          ),
        ),
        SizedBox(height: 10),
        ListView.builder(
          shrinkWrap: true,
          itemCount: bookingEntries.length,
          itemBuilder: (context, index) {
            final entry = bookingEntries[index];
            return Card(
              child: ListTile(
                title: Text('${entry.name} - ${entry.route}'),
                subtitle: Text('Seat No.: ${entry.seat_no}'),
              ),
            );
          },
        ),
      ],
    );
  }

  Future<void> _validateFields() async {
    bool isValid = _name.isNotEmpty &&
        _email.isNotEmpty &&
        _cnic.isNotEmpty &&
        _phoneNo.isNotEmpty &&
        _seatNo.isNotEmpty;

    if (isValid) {
      bool seatAlreadyBooked = bookingEntries.any((entry) =>
          entry.route == _selectedRoute &&
          entry.seat_no == _seatNo &&
          entry.departure_date == _departureDate &&
          entry.departure_time == _selectedTime);

      if (!seatAlreadyBooked) {
        if (bookedSeats[_selectedRoute]! < 24) {
          bookedSeats[_selectedRoute] = bookedSeats[_selectedRoute]! + 1;
          _seatNo = (bookedSeats[_selectedRoute]!).toString();

          booking_entry entry = booking_entry(
            _name,
            _email,
            _cnic,
            _phoneNo,
            _seatNo,
            _selectedSeatType,
            _selectedRoute,
            _departureDate,
            _selectedTime,
          );

          await sharedpref.writeBookingEntry(entry);
          print('Saved booking entry: $entry');

          setState(() {
            bookingEntries = sharedpref.getAllofBookingData();
            print('Updated booking entries: $bookingEntries');
          });

          // Show booking confirmation dialog
          _showBookingConfirmationDialog();
        } else {
          _showErrorDialog('The Slot is already Filled');
        }
      } else {
        _showErrorDialog('This seat is not available');
      }
    } else {
      setState(() {
        _nameError = _name.isEmpty;
        _emailError = _email.isEmpty;
        _cnicError = _cnic.isEmpty;
        _phoneNoError = _phoneNo.isEmpty;
        _seatNoError = _seatNo.isEmpty;
      });
    }
  }

  void _showBookingConfirmationDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Booking Confirmed'),
          content: Text('Your booking has been done successfully.'),
          actions: <Widget>[
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Error'),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _pickDepartureDate() async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: _departureDate,
      firstDate: DateTime.now(),
      lastDate: DateTime(DateTime.now().year + 1),
    );

    if (pickedDate != null) {
      setState(() {
        _departureDate = pickedDate;
      });
    }
  }
}
