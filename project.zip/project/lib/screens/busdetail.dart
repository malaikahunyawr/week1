import 'package:flutter/material.dart';

class BusDetailsScreen extends StatelessWidget {
  final String busType;
  final String details;

  const BusDetailsScreen({required this.busType, required this.details});

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: Text(busType),
        backgroundColor: Colors.blueAccent,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        child: Stack(
          children: [
            Image.asset(
              busType == 'Business Class' ? 'assets/bg.jpeg' : 'assets/bg.jpeg',
              fit: BoxFit.cover,
              height: screenHeight,
              width: double.infinity,
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  SizedBox(height: 20),
                  Text(
                    details,
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 16,
                    ),
                  ),
                  SizedBox(height: 20),
                  Table(
                    border: TableBorder.all(color: Colors.black),
                    children: [
                      TableRow(
                        children: [
                          TableCell(
                            child: Center(
                              child: Text(
                                'Route',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                ),
                              ),
                            ),
                          ),
                          TableCell(
                            child: Center(
                              child: Text(
                                'First Bus',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                ),
                              ),
                            ),
                          ),
                          TableCell(
                            child: Center(
                              child: Text(
                                'Second Bus',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                ),
                              ),
                            ),
                          ),
                          TableCell(
                            child: Center(
                              child: Text(
                                'Last Bus',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                ),
                              ),
                            ),
                          ),
                          TableCell(
                            // New TableCell for the additional column
                            child: Center(
                              child: Text(
                                'Price', // Label for the additional column
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      ..._getRouteRows(busType),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<TableRow> _getRouteRows(String busType) {
    if (busType == 'Business Class') {
      return [
        _buildTableRow(
            'Lahore to Islamabad', '9:00 AM', '5:00 PM', '10:00 PM', 'Rs 4000'),
        _buildTableRow('Lahore to Faisalabad', '9:00 AM', '5:00 PM', '10:00 PM',
            'Rs 2500'),
        _buildTableRow(
            'Lahore to Multan', '9:00 AM', '5:00 PM', '10:00 PM', 'Rs 3000'),
        _buildTableRow(
            'Islamabad to Lahore', '9:00 AM', '5:00 PM', '10:00 PM', 'Rs 4000'),
        _buildTableRow('Faisalabad to Lahore', '9:00 AM', '5:00 PM', '10:00 PM',
            'Rs 2500'),
        _buildTableRow(
            'Multan to Lahore', '9:00 AM', '5:00 PM', '10:00 PM', 'Rs 3000'),
      ];
    } else {
      return [
        _buildTableRow(
            'Lahore to Islamabad', '9:00 AM', '5:00 PM', '10:00 PM', 'Rs 1500'),
        _buildTableRow('Lahore to Faisalabad', '9:00 AM', '5:00 PM', '10:00 PM',
            'Rs 1000'),
        _buildTableRow(
            'Lahore to Multan', '9:00 AM', '5:00 PM', '10:00 PM', 'Rs 1200'),
        _buildTableRow(
            'Islamabad to Lahore', '9:00 AM', '5:00 PM', '10:00 PM', 'Rs 1500'),
        _buildTableRow('Faisalabad to Lahore', '9:00 AM', '5:00 PM', '10:00 PM',
            'Rs 1000'),
        _buildTableRow(
            'Multan to Lahore', '9:00 AM', '5:00 PM', '10:00 PM', 'Rs 1200'),
      ];
    }
  }

  TableRow _buildTableRow(String route, String firstBus, String lastBus,
      String price, String availability) {
    return TableRow(
      children: [
        TableCell(
          child: Center(
            child: Text(
              route,
              style: TextStyle(color: Colors.black),
            ),
          ),
        ),
        TableCell(
          child: Center(
            child: Text(
              firstBus,
              style: TextStyle(color: Colors.black),
            ),
          ),
        ),
        TableCell(
          child: Center(
            child: Text(
              lastBus,
              style: TextStyle(color: Colors.black),
            ),
          ),
        ),
        TableCell(
          child: Center(
            child: Text(
              price,
              style: TextStyle(color: Colors.black),
            ),
          ),
        ),
        TableCell(
          child: Center(
            child: Text(
              availability,
              style: TextStyle(color: Colors.black),
            ),
          ),
        ),
      ],
    );
  }
}
