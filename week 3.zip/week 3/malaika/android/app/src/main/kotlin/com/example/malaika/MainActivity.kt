package com.example.malaika

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
