import 'package:flutter/material.dart';
import 'package:malaika/screen/homescreen.dart';
import 'package:malaika/screen/meritscreen.dart';

void main() {
  runApp(const tourApp());
}

class tourApp extends StatelessWidget {
  const tourApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      routes: {
        "/": (context) => homescreen(),
        "/merit": (context) => MeritScreen()
      },
      initialRoute: "/",
    );
  }
}
