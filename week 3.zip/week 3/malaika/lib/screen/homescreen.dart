import 'package:flutter/material.dart';
import'package:malaika/common/menudrawer.dart';
import "../common/navigationbar.dart";
class homescreen extends StatelessWidget {
  const homescreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
appBar: AppBar(title: Center(child: Text("gcu App")),
backgroundColor: Colors.blueAccent,
foregroundColor: Colors.white,

),
drawer: const menudrawer(),
bottomNavigationBar: MyBottomNavBar(),
body: Container(

  decoration: BoxDecoration(
    image: DecorationImage(
                  image : AssetImage("image/hunza.jpeg"), fit: BoxFit.fill)),
  child: Center(
    child: Container(
       padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(2)),
                    color: Colors.blue),
    child : Text(
      "welcome to the dept of CS",
     style: TextStyle(fontSize: 20) ,

    
    )
    
    
    )
    
    ),

  ),
);
  }
}