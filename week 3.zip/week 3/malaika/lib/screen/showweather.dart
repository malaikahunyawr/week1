//import 'dart:io';

import 'package:flutter/material.dart';
import 'package:malaika/common/menudrawer.dart';
import 'package:malaika/screen/weather/http_helper.dart';
//import "../common/navigationbar.dart";
//import 'package:malaika/screen/weather/http_helper.dart'; // Correct import path for HttpHelper
import 'package:malaika/screen/weather/weather.dart'; // Correct import path for Weather

class ShowWeather extends StatefulWidget {
  // Renamed Weather to ShowWeather
  const ShowWeather({Key? key}) : super(key: key);

  @override
  State<ShowWeather> createState() =>
      _ShowWeatherState(); // Renamed _WeatherState to _ShowWeatherState
}

class _ShowWeatherState extends State<ShowWeather> {
  // Renamed _WeatherState to _ShowWeatherState
  HTTPHelper httpHelper = HTTPHelper();
  Weather weatherData = Weather(0, 0, 0, "", 0, "");
  String weatherInfo = "";

  @override
  void initState() {
    super.initState();
    // Fetch weather data and update state
    httpHelper.GetWeatherOfGCU().then((weatherObj) {
      setState(() {
        weatherData = weatherData;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(
            child:
                Text('Weather Update', style: TextStyle(color: Colors.white))),
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      drawer: const menudrawer(),
      body: Column(
        children: [
          weatherRowWidget(
              "Temperature", weatherData.temperature.toStringAsFixed(3)),
          weatherRowWidget("Description", weatherData.description),
          weatherRowWidget("wind speed", weatherData.windSpeed.toString()),
          weatherRowWidget("city name", weatherData.cityName.toString()),
          weatherRowWidget("Humidity", weatherData.humidity.toString()),
        ],
      ),
    );
  }
}

Widget weatherRowWidget(String label, String value) {
  // Renamed weatherRow to weatherRowWidget
  return Row(
    children: [
      Expanded(
        flex: 60,
        child: Text(
          label,
          style: const TextStyle(color: Colors.black, fontSize: 27),
        ),
      ),
      Expanded(
        flex: 60,
        child: Text(
          value,
          style: const TextStyle(color: Colors.black, fontSize: 27),
        ),
      ),
    ],
  );
}
