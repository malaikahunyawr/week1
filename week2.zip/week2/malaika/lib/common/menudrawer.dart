import 'package:flutter/material.dart';
import 'package:malaika/screen/homescreen.dart';
import 'package:malaika/screen/meritscreen.dart';
class menudrawer extends StatelessWidget {
  const menudrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: Colors.blueGrey,
      child: ListView(
        children: buildMenuItems(context),
      ),
    );
  }

  List<Widget> buildMenuItems(BuildContext context) {
    List<Widget> menuItems = [];
    menuItems.add(const DrawerHeader(
        child: Text(
      "GCU App Options",
      style: TextStyle(fontSize: 30),
    )));

    final Set<String> menuTitles = {
      "Home",
      "Merit Calculator",
      "Sports",
      "About"
    };
    menuTitles.forEach((element) {
      menuItems.add(ListTile(
        title: Text(
          element,
          style: const TextStyle(fontSize: 20),
        ),
        onTap: () {
          Widget screen = Container();
          switch (element) {
            case "Home":
              screen = homescreen();
              break;
            case "Merit Calculator":
              screen = meritscreen();
              break;
            default:
          }

          Navigator.of(context).pop();
          Navigator.of(context)
              .push(MaterialPageRoute(builder: (context) => screen));
        },
      ));
    });
    return menuItems;

  }
}