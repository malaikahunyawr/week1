import 'package:flutter/material.dart';

import "../common/navigationbar.dart";
import'package:malaika/common/menudrawer.dart';
class meritscreen extends StatelessWidget {
  const meritscreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
appBar: AppBar(title: Text("merit screen"),
backgroundColor: Colors.blue,
),
drawer: const menudrawer(),
bottomNavigationBar: MyBottomNavBar(),
body: Center(child: Text("merit screen")),
    );
  }
}